package com.cg.service;

import com.cg.dao.EBillDAOImpl;
import com.cg.dao.IEBillDAO;
import com.cg.dto.BillDTO;
import com.cg.exception.BillUserException;

public class EBillServiceImpl implements IBillService {
	private IEBillDAO ebillDAO;
	
	public EBillServiceImpl() throws BillUserException {
		super();
		ebillDAO = new EBillDAOImpl();
	}

	@Override
	public boolean insert(BillDTO billDTO) throws BillUserException {
		String name = null;
		
		return ebillDAO.insert(billDTO);
		
	}

	@Override
	public String getConsName(int consumerNo) throws BillUserException {
		// TODO Auto-generated method stub
		return ebillDAO.getConsName(consumerNo);
	}

}
