package com.cg.service;

import com.cg.dto.BillDTO;
import com.cg.exception.BillUserException;

public interface IBillService{
	public boolean insert(BillDTO billDTO)throws BillUserException;
	public String getConsName(int consumerNo) throws
	BillUserException;
}
